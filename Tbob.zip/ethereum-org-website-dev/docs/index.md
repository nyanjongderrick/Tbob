---
title: Home
meta:
  - name: description
    content: Ethereum is a global, decentralized platform for money and new kinds of applications. On Ethereum, you can write code that controls money, and build applications accessible anywhere in the world.
  - property: og:title
    content: Home | Ethereum
  - property: og:description
    content: Ethereum is a global, decentralized platform for money and new kinds of applications. On Ethereum, you can write code that controls money, and build applications accessible anywhere in the world.
lang: en-US
layout: home
---

<HomePage/>